from abc import ABC, abstractmethod

class TabInterface(ABC):

    @abstractmethod
    def process_tab():
        pass